--Print All Tables

select* from Admin 
select* from Employee 
select* from customer 
select* from Loan 
select* from Account 
select* from Branch 
select* from Bank

--Delete All Tables

delete from Admin
delete from Employee
delete from customer
delete from Loan
delete from Account
delete from Branch
delete from Bank
